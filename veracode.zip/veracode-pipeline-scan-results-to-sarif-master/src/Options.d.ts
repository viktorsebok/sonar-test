export interface Options {
    inputFilename: string,
    outputFilename: string,
    ruleLevel: string,
    pathReplacers: string,
}