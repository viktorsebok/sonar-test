import { IMasterAssetModel, OPCUABuilder } from '@oi4/oi4-oec-service-opcua-model';
import { AsyncMqttClient } from 'async-mqtt';
import { ProducerAsset } from './ProducerAsset';
import { DataResourceType } from './Resources/Data/DataResourceType';
export declare class DeviceAsset extends ProducerAsset {
    get allResources(): import("../Common/ObservableArray").ObservableArray<import("./Resources/Base/IOecResource").IOecResource<any>>;
    constructor(mqtt: AsyncMqttClient, mam: IMasterAssetModel, builder: OPCUABuilder, topicPreamble: string, dataResourceType?: DataResourceType[] | undefined);
}
