/// <reference types="node" />
import EventEmitter from 'events';
import { AssetId } from '../Common/AssetId';
import { ObservableArray } from '../Common/ObservableArray';
import { ResourceType } from '../Common/ResourceType';
import { IOecResource } from './Resources/Base/IOecResource';
export declare class Asset {
    readonly assetId: AssetId;
    protected eventEmitter: EventEmitter;
    protected resources: ObservableArray<IOecResource<any>>;
    constructor(assetId: AssetId, resources: IOecResource<any>[]);
    constructor(manufaturerUrl: string, productName: string, productCode: string, serialNumber: string, resources: IOecResource<any>[]);
    on(eventName: string | symbol, listener: (...args: any[]) => void): void;
    getResourceInstance<T>(classType: new (...args: any[]) => T): T | undefined;
    /**
        * @deprecated Use getResourceInstance function instead!
    */
    getResource<R>(resource: ResourceType): IOecResource<R>;
    equals(toCompare: Asset): boolean;
}
