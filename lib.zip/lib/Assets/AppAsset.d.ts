import { IMasterAssetModel, OPCUABuilder } from '@oi4/oi4-oec-service-opcua-model';
import { AsyncMqttClient } from 'async-mqtt';
import { DeviceAsset } from './DeviceAsset';
import { ProducerAsset } from './ProducerAsset';
import { AssetId } from '../Common/AssetId';
import { DataResourceType } from './Resources/Data/DataResourceType';
export declare class AppAsset extends ProducerAsset {
    constructor(mqtt: AsyncMqttClient, mam: IMasterAssetModel, appId: AssetId, builder: OPCUABuilder, dataResourceType?: DataResourceType[] | undefined);
    addDevice(mam: IMasterAssetModel, dataResourceType?: DataResourceType[] | undefined): Promise<DeviceAsset | null>;
    static getTopicPreample(mam: IMasterAssetModel, appId: AssetId): string;
}
