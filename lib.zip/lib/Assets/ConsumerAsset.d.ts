import { OPCUABuilder } from '@oi4/oi4-oec-service-opcua-model';
import { AsyncMqttClient } from 'async-mqtt';
import { AssetId } from '../Common/AssetId';
import { Asset } from './Asset';
export declare interface ConsumerAsset {
    on(event: 'synchronized', cb: (asset: ConsumerAsset) => void): this;
}
export declare class ConsumerAsset extends Asset {
    private topicPreamble;
    private asset;
    private mqtt;
    private builder;
    get synchronized(): boolean;
    constructor(topicPreamble: string, asset: AssetId, mqtt: AsyncMqttClient, builder: OPCUABuilder);
    private startServices;
    private resourceSyncChanged;
}
