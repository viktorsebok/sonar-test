import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../Common/AssetId";
import { Asset } from "./Asset";
import { DataResourceType } from "./Resources/Data/DataResourceType";
export declare class ProducerAsset extends Asset {
    protected mqtt: AsyncMqttClient;
    protected builder: OPCUABuilder;
    protected topicPreamble: string;
    constructor(mqtt: AsyncMqttClient, assetId: AssetId, builder: OPCUABuilder, topicPreamble: string);
    protected addDataResource(dataResource: DataResourceType): void;
}
