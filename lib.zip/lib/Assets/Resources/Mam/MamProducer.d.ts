import { OecProducerResource } from '../Base/OecProducerResource';
import { IMasterAssetModel, OPCUABuilder } from '@oi4/oi4-oec-service-opcua-model';
import { AssetId } from '../../..';
import { AsyncMqttClient } from 'async-mqtt';
export declare class MamProducer extends OecProducerResource<IMasterAssetModel> {
    resource: string;
    oecResource: IMasterAssetModel;
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId, mam: IMasterAssetModel);
    start(): Promise<void>;
    private publish;
    private onMamGet;
}
