import { IMasterAssetModel, OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../Common/AssetId";
import { OecConsumerResource } from "../Base/OecConsumerResource";
export declare class MamConsumer extends OecConsumerResource<IMasterAssetModel> {
    resource: string;
    oecResource: IMasterAssetModel;
    get synchronized(): boolean;
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
    private request;
    private onMamPub;
}
