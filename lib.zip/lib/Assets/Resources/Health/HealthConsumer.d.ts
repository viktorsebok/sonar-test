import { IContainerHealth } from "@oi4/oi4-oec-service-model";
import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../Common/AssetId";
import { OecConsumerResource } from "../Base/OecConsumerResource";
export declare class HealthConsumer extends OecConsumerResource<IContainerHealth> {
    private healthResolver;
    resource: string;
    oecResource: IContainerHealth;
    get synchronized(): boolean;
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
    private request;
    private onHealthPub;
}
