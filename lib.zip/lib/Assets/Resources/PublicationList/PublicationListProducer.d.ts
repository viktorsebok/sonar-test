import { OecProducerResource } from '../Base/OecProducerResource';
import { IContainerPublicationList } from '@oi4/oi4-oec-service-model';
import { OPCUABuilder } from '@oi4/oi4-oec-service-opcua-model';
import { AssetId } from '../../..';
import { ObservableArray } from '../../../Common/ObservableArray';
import { AsyncMqttClient } from 'async-mqtt';
import { IOecProducerResource } from '../Base/IOecProducerResource';
export declare abstract class PublicationList extends OecProducerResource<IContainerPublicationList> {
}
export declare class PublicationListProducer extends PublicationList {
    resource: string;
    oecResource: IContainerPublicationList;
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId, resources: ObservableArray<IOecProducerResource<any>>);
    private attach;
    private removePubItem;
    private publish;
    private onPubListGet;
}
