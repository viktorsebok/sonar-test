import { OecProducerResource } from '../Base/OecProducerResource';
import { IContainerProfile } from '@oi4/oi4-oec-service-model';
import { OPCUABuilder } from '@oi4/oi4-oec-service-opcua-model';
import { AssetId } from '../../..';
import { ObservableArray } from '../../../Common/ObservableArray';
import { AsyncMqttClient } from 'async-mqtt';
import { IOecResource } from '../Base/IOecResource';
export declare class ProfileProducer extends OecProducerResource<IContainerProfile> {
    resource: string;
    oecResource: IContainerProfile;
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId, resources: ObservableArray<IOecResource<any>>);
    private publish;
    private onProfileGet;
}
