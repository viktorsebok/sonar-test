import { IContainerProfile } from "@oi4/oi4-oec-service-model";
import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../Common/AssetId";
import { OecConsumerResource } from "../Base/OecConsumerResource";
export declare class ProfileConsumer extends OecConsumerResource<IContainerProfile> {
    resource: string;
    oecResource: IContainerProfile;
    get synchronized(): boolean;
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
    request(): Promise<void>;
    private onProfilePub;
}
