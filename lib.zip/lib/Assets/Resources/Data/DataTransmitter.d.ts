import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../Common/AssetId";
import { OecProducerResource } from "../Base/OecProducerResource";
export declare abstract class DataTransmitter<T> extends OecProducerResource<T[]> {
    private classId;
    synchronized: boolean;
    resource: string;
    oecResource: T[];
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId, classId: string, classType: Function);
    protected publish(payloads: [T, Date][], asset: AssetId, filter: string): Promise<void>;
}
