export interface IDeviceParameterListElementData {
    Parameter: string;
    ParameterInfo: object;
}
