import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../../Common/AssetId";
import { DataConsumer } from "../DataConsumer";
import { IDeviceParameterListData } from "./IDeviceParameterListData";
export declare class DeviceParameterListDataConsumer extends DataConsumer<IDeviceParameterListData> {
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
}
