import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../../Common/AssetId";
import { DataProducer } from "../DataProducer";
import { IDeviceParameterListData } from "./IDeviceParameterListData";
export declare const DATA_CLASSID_PARAMETER_LIST: string;
export declare class DeviceParameterListDataProducer extends DataProducer<IDeviceParameterListData> {
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
}
