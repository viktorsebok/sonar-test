import { IDeviceParameterListElementData } from "./DeviceParameterListElementData/IDeviceParameterListElementData";
export interface IDeviceParameterListData {
    Parameters: IDeviceParameterListElementData[];
}
