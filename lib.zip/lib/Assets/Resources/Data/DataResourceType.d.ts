export declare enum DataResourceType {
    None = 0,
    Unknown = 1,
    DeviceParameterData = 2,
    DeviceParameterListData = 3,
    TimeSeriesTransmitter = 4,
    TimeSeriesReceiver = 5,
    AlarmTransmitter = 6,
    AlarmReceiver = 7,
    PeriodicParameter = 8,
    SettingsTransmitter = 9,
    SettingsReceiver = 10
}
