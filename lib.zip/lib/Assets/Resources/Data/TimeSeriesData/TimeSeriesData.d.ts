export declare const FILTER_TIME_SERIES = "TimeSeries";
export declare const CLASSID_TIME_SERIES = "09afa621-2c7a-4a15-9b36-c41ad61988ea";
export declare class TimeSeriesData {
    Parameter: string;
    Value: string;
    constructor(parameter: string, value: string);
}
