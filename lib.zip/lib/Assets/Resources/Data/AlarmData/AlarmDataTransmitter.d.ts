import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../../Common/AssetId";
import { DataTransmitter } from "../DataTransmitter";
import { AlarmData } from "./AlarmData";
export declare class AlarmDataTransmitter extends DataTransmitter<AlarmData> {
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
    publish(payloads: [AlarmData, Date][], asset: AssetId): Promise<void>;
}
