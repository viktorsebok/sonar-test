import { AlarmSeverity } from "./AlarmSeverity";
export declare const FILTER_TOPIC_ALARM = "Alarm";
export declare const CLASSID_ALARM = "070ab6c2-844c-429f-a034-242bec858cb4";
export declare class AlarmData {
    Severity: AlarmSeverity;
    Group: string;
    Name: string;
    Identifier: string;
    Message: string;
    constructor(severity: AlarmSeverity, group: string, name: string, message: string, identifier: string);
}
