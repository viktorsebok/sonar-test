import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../Common/AssetId";
import { DataConsumer } from "./DataConsumer";
export declare abstract class DataReceiver<T> extends DataConsumer<T> {
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId, filter: string, classId: string, classType: Function);
}
