/// <reference types="node" />
import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../Common/AssetId";
import { OecProducerResource } from "../Base/OecProducerResource";
export declare type DataRequestCallback<T> = (request: T[], filter: AssetId | null) => Promise<[T, Date][] | undefined>;
export declare class DataProducer<T> extends OecProducerResource<T[]> {
    private classId;
    resource: string;
    oecResource: T[];
    private handlerGet;
    private handlerSet;
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId, classId: string, classType: Function);
    subscribeData(callbackGet: DataRequestCallback<T>, callbackSet: DataRequestCallback<T>): void;
    publish(payloads: [T, Date][], filter?: AssetId | null, correlationId?: string): Promise<void>;
    protected onDataGet(payload: Buffer, topic?: string): Promise<void>;
    protected onDataSet(payload: Buffer, topic?: string): Promise<void>;
    private handleRequest;
}
