/// <reference types="node" />
import { IOPCUANetworkMessage, OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../Common/AssetId";
import { IOecConsumerResource } from "../Base/IOecConsumerResource";
import { OecConsumerResource } from "../Base/OecConsumerResource";
export declare interface DataConsumer<T> {
    on(event: 'synchronized', cb: (resource: IOecConsumerResource<T[]>) => void): this;
    on(event: 'changed', cb: (resource: IOecConsumerResource<T[]>) => void): this;
    on(event: 'data', cb: (payload: [T, Date, AssetId][]) => void): this;
    on(event: 'rawdata', cb: (msg: IOPCUANetworkMessage) => void): this;
}
export declare class DataConsumer<T> extends OecConsumerResource<T[]> {
    private classId;
    resource: string;
    oecResource: T[];
    get synchronized(): boolean;
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId, classId: string, classType: Function);
    get(request: [T, Date][], filter?: AssetId | null, timeout?: number): Promise<[T, Date, AssetId][] | null>;
    set(request: [T, Date][], filter?: AssetId | null, timeout?: number): Promise<[T, Date, AssetId][] | null>;
    private waitForAnswer;
    private request;
    protected onDataPub(payload: Buffer, topic?: string): Promise<void>;
}
