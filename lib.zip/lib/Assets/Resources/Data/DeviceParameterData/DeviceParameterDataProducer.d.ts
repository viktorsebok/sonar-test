import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../../Common/AssetId";
import { DataProducer } from "../DataProducer";
import { IDeviceParameterData } from "./IDeviceParameterData";
export declare const DATA_CLASSID_DEV_PARAMETER: string;
export declare class DeviceParameterDataProducer extends DataProducer<IDeviceParameterData> {
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
}
