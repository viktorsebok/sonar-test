export interface IDeviceParameterData {
    Parameter: string;
    ParameterInfo: any;
    Value: string;
    ErrorCode: number;
    ErrorMessage: string;
}
