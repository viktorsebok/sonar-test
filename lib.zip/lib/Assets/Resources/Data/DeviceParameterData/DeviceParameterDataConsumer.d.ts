import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../../Common/AssetId";
import { DataConsumer } from "../DataConsumer";
import { IDeviceParameterData } from "./IDeviceParameterData";
export declare class DeviceParameterDataConsumer extends DataConsumer<IDeviceParameterData> {
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
}
