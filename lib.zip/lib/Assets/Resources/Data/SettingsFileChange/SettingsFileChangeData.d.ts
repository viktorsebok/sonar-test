import { ApplicationId } from "@ametek-dunker-iiot/common-lib-schemes";
import { SettingsFileChangeReason } from "./SettingsFileChangeReason";
export declare const FILTER_SETTINGS_CHANGE = "settings";
export declare const CLASSID_SETTINGS_CHANGE = "29fffae7-4738-4149-ad6f-d54f23a9f90a";
export declare class SettingsFileChangeData {
    ApplicationId: ApplicationId;
    SettingsId: string;
    Change: SettingsFileChangeReason;
    constructor(application: ApplicationId, change: SettingsFileChangeReason, settingsId: string);
}
