import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../../Common/AssetId";
import { DataReceiver } from "../DataReceiver";
import { SettingsFileChangeData } from "./SettingsFileChangeData";
export declare class SettingsFileChangeReceiver extends DataReceiver<SettingsFileChangeData> {
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
    start(): Promise<void>;
}
