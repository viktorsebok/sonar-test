export declare enum SettingsFileChangeReason {
    add = "ADD",
    delete = "DELETE",
    update = "UPDATE"
}
