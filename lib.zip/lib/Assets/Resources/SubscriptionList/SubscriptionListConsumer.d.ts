import { IContainerSubscriptionList } from "@oi4/oi4-oec-service-model";
import { OPCUABuilder } from "@oi4/oi4-oec-service-opcua-model";
import { AsyncMqttClient } from "async-mqtt";
import { AssetId } from "../../../Common/AssetId";
import { OecConsumerResource } from "../Base/OecConsumerResource";
export declare class SubscriptionListConsumer extends OecConsumerResource<IContainerSubscriptionList> {
    resource: string;
    oecResource: IContainerSubscriptionList;
    get synchronized(): boolean;
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
    private request;
    private onSubListPub;
}
