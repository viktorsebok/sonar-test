import { OecProducerResource } from '../Base/OecProducerResource';
import { IContainerLicense, ILicenseObject } from '@oi4/oi4-oec-service-model';
import { OPCUABuilder } from '@oi4/oi4-oec-service-opcua-model';
import { AsyncMqttClient } from 'async-mqtt';
import { AssetId } from '../../../Common/AssetId';
export declare class LicenseProducer extends OecProducerResource<IContainerLicense> {
    resource: string;
    oecResource: IContainerLicense;
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId, licenses?: ILicenseObject[]);
    addLicense(licenses: ILicenseObject[]): Promise<void>;
    private publish;
    private onLicenseGet;
}
