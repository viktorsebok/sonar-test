/// <reference types="node" />
import EventEmitter = require('events');
import { AsyncMqttClient } from 'async-mqtt';
export declare interface PeriodicParameterControllerInterface {
    on(event: 'expired', listener: (sender: PeriodicParameterController) => void): this;
    signal(enable: boolean): void;
}
export declare class PeriodicParameterController extends EventEmitter implements PeriodicParameterControllerInterface {
    private _lastSignal;
    get lastSignal(): number;
    private topic;
    private message;
    private mqtt;
    constructor(mqtt: AsyncMqttClient, topic: string, message: any);
    signal(enable?: boolean): void;
    private onTimeout;
}
