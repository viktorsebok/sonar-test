export interface IPeriodicParameterMessage {
    Parameter: string;
    Period: number;
    Value: string;
    ErrorCode: number;
    ErrorMessage: string;
    ParameterInfo: any;
}
