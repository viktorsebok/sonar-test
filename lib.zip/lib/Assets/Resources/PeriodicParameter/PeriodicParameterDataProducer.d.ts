import { OPCUABuilder } from '@oi4/oi4-oec-service-opcua-model';
import { AsyncMqttClient } from 'async-mqtt';
import { AssetId } from '../../../Common/AssetId';
import { IPeriodicParameterMessage } from './IPeriodicParameterMessage';
import { OecProducerResource } from '../Base/OecProducerResource';
import { IDeviceParameterData } from '../Data/DeviceParameterData/IDeviceParameterData';
import { DeviceParameterDataProducer } from '../Data/DeviceParameterData/DeviceParameterDataProducer';
export declare type DataRequestCallback = (request: IDeviceParameterData[], filter: AssetId | null) => Promise<[IDeviceParameterData, Date][] | undefined>;
export declare class PeriodicParameterDataProducer extends OecProducerResource<IPeriodicParameterMessage> {
    synchronized: boolean;
    oecResource: IPeriodicParameterMessage;
    readonly resource = "periodic";
    private dataProducer?;
    private handlerReadInterval?;
    private pendingMessages;
    private pubtopic;
    private periodicParameters;
    private parameterPeriodsMap;
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
    registerHandler(handler: DataRequestCallback, dataProducer: DeviceParameterDataProducer): void;
    private onPeriodicRequest;
    private updateExistingParameter;
    private addNewParameter;
    private signal;
    private transmitData;
    private removeExpiredParameters;
    private periodicReadRequest;
}
