import { OPCUABuilder } from '@oi4/oi4-oec-service-opcua-model';
import { AsyncMqttClient } from 'async-mqtt';
import { AssetId } from '../../../Common/AssetId';
import { OecConsumerResource } from '../Base/OecConsumerResource';
import { IPeriodicParameterMessage } from './IPeriodicParameterMessage';
import { PeriodicParameterController } from './PeriodicParameterController';
export declare class PeriodicParameterConsumer extends OecConsumerResource<IPeriodicParameterMessage> {
    synchronized: boolean;
    oecResource: IPeriodicParameterMessage;
    readonly resource = "periodic";
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
    commit(parameters: any[]): PeriodicParameterController;
}
