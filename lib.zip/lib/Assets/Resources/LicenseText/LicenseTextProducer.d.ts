import { OecProducerResource } from '../Base/OecProducerResource';
import { IContainerLicenseText } from '@oi4/oi4-oec-service-model';
import { OPCUABuilder } from '@oi4/oi4-oec-service-opcua-model';
import { AssetId } from '../../..';
import { AsyncMqttClient } from 'async-mqtt';
export declare class LicenseTextProducer extends OecProducerResource<IContainerLicenseText> {
    resource: string;
    oecResource: IContainerLicenseText;
    constructor(mqtt: AsyncMqttClient, topicPreamble: string, builder: OPCUABuilder, assetId: AssetId);
    private publish;
    private onLicenseTextGet;
}
