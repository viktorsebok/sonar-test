import { IPublicationListObject } from "@oi4/oi4-oec-service-model";
import { ObservableArray } from "../../../Common/ObservableArray";
import { IOecProducerResource } from "./IOecProducerResource";
import { OecResource } from "./OecResource";
export declare abstract class OecProducerResource<R> extends OecResource<R> implements IOecProducerResource<R> {
    readonly publications: ObservableArray<IPublicationListObject>;
    start(): Promise<void>;
}
