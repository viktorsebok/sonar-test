import { IOecConsumerResource } from "./IOecConsumerResource";
import { OecResource } from "./OecResource";
export declare interface OecConsumerResource<R> {
    on(event: 'synchronized', cb: (resource: IOecConsumerResource<R>) => void): this;
    on(event: 'changed', cb: (resource: IOecConsumerResource<R>) => void): this;
}
export declare abstract class OecConsumerResource<R> extends OecResource<R> implements IOecConsumerResource<R> {
    abstract synchronized: boolean;
}
