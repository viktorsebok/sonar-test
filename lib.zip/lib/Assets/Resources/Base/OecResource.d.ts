/// <reference types="node" />
import EventEmitter = require('events');
import { AssetId } from '../../../Common/AssetId';
import { OPCUABuilder, IOPCUANetworkMessage } from '@oi4/oi4-oec-service-opcua-model';
import { AsyncMqttClient } from 'async-mqtt';
import { IOecResource } from './IOecResource';
export declare abstract class OecResource<R> implements IOecResource<R> {
    protected mqtt: AsyncMqttClient;
    protected assetId: AssetId;
    protected topicPreamble: string;
    protected opcBuilder: OPCUABuilder;
    abstract readonly resource: string;
    abstract readonly oecResource: R;
    readonly tName: string;
    protected eventEmitter: EventEmitter;
    private subscibers;
    constructor(mqtt: AsyncMqttClient, assetId: AssetId, topicPreamble: string, opcBuilder: OPCUABuilder, classType: Function);
    on(eventName: string | symbol, listener: (...args: any[]) => void): void;
    off(eventName: string | symbol, listener: (...args: any[]) => void): void;
    protected subscribe(topic: string, callback: (message: Buffer, topic?: string) => void): Promise<void>;
    protected unsubscribe(topic: string): Promise<void>;
    private onMessage;
    protected getOecNetworkMessage(message: Buffer): Promise<IOPCUANetworkMessage | null>;
}
