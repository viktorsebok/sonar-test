export interface IOecResource<R> {
    readonly tName: string;
    readonly resource: string;
    readonly oecResource: R;
}
