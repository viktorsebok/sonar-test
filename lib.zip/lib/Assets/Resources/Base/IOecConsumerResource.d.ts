import { IOecResource } from "./IOecResource";
export interface IOecConsumerResource<R> extends IOecResource<R> {
    synchronized: boolean;
}
