/// <reference types="node" />
export interface IOecMessageSubscriber {
    topic: string;
    callback: (message: Buffer, topic?: string) => void;
}
