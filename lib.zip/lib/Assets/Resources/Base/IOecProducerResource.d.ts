import { IPublicationListObject } from "@oi4/oi4-oec-service-model";
import { ObservableArray } from "../../../Common/ObservableArray";
import { IOecResource } from "./IOecResource";
export interface IOecProducerResource<R> extends IOecResource<R> {
    readonly publications: ObservableArray<IPublicationListObject>;
    start(): Promise<void>;
}
