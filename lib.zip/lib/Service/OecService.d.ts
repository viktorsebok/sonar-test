import { AsyncMqttClient } from 'async-mqtt';
import { AppAsset } from '../Assets/AppAsset';
import { Asset } from '../Assets/Asset';
import { IMasterAssetModel } from '@oi4/oi4-oec-service-opcua-model';
import { DataResourceType } from '../Assets/Resources/Data/DataResourceType';
import { AssetId } from '../Common/AssetId';
export declare interface OecService {
    on(eventName: 'newasset', listener: (asset: Asset) => void): any;
}
export declare class OecService {
    private eventEmitter;
    private mqttProvider;
    private assetProvider;
    private mqttConfigurator;
    get assets(): Asset[];
    get mqttClient(): AsyncMqttClient;
    constructor();
    start(mam: IMasterAssetModel, dataResourceType?: DataResourceType[] | undefined): Promise<AppAsset | null>;
    getAsset(assetId: AssetId): Asset | undefined;
    private initAssetProvider;
    private setLastWill;
    private setCustomSchemas;
}
