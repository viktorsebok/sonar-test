import { OPCUABuilder } from '@oi4/oi4-oec-service-opcua-model';
import { AsyncMqttClient } from 'async-mqtt';
import { Asset } from '../Assets/Asset';
export declare class AssetManagement {
    private allAssets;
    private eventEmitter;
    private registryFound;
    get assets(): Asset[];
    private mqtt;
    private builder;
    constructor(mqtt: AsyncMqttClient, builder: OPCUABuilder);
    on(eventName: string | symbol, listener: (...args: any[]) => void): void;
    start(): Promise<void>;
    private onMqttMessage;
    private registerConsumerAssetByTopicFilter;
    private registerConsumerAssetByTopicOriginator;
    private registerConsumerAsset;
}
