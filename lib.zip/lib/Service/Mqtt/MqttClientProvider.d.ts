import { AsyncMqttClient } from 'async-mqtt';
import { MqttConfigurator } from './MqttConfigurator';
export declare class MqttClientProvider {
    mqttClient: AsyncMqttClient;
    connect(config: MqttConfigurator): Promise<AsyncMqttClient>;
}
