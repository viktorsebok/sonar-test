export declare class MqttConfigurator {
    valid: boolean;
    readonly address: string;
    readonly port: number;
    readonly clientName: string;
    readonly unsecured: boolean;
    readonly user: string;
    readonly password: string;
    lastWillTopic: string;
    lastWillPayload: string;
    constructor();
    private invalidate;
    private checkIsStringTrue;
}
