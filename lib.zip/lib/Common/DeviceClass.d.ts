export declare enum DeviceClass {
    MotorMCP = "MotorMCP",
    MotorXI = "MotorXI",
    MotorSI = "MotorSI",
    Robot = "Robot",
    RobotController = "RobotController",
    RobotProgramm = "RobotProgramm",
    Generic = "Generic"
}
