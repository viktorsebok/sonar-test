import { IMasterAssetModel } from "@oi4/oi4-oec-service-opcua-model";
export declare class AssetId {
    readonly manufaturerUrl: string;
    readonly productName: string;
    readonly productCode: string;
    readonly serialNumber: string;
    get value(): string;
    get valueEncodedUri(): string;
    constructor(manufaturerUrl: string, productName: string, productCode: string, serialNumber: string);
    equals(toCompare: AssetId): boolean;
    static createByTopic(topic: string): AssetId | null;
    static createByTopicFilter(topic: string): AssetId | null;
    static createByTopicOriginator(topic: string): AssetId | null;
    static createByMam(mam: IMasterAssetModel): AssetId;
    static getTopicPreable(topic: string): string | null;
}
