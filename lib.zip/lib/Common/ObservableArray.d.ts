export declare class ObservableArray<T> extends Array<T> {
    private emitter;
    push(...items: T[]): number;
    splice(start: number, deleteCount?: number): T[];
    on(eventName: string | symbol, listener: (...args: any[]) => void): void;
}
