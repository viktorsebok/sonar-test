export declare enum ServiceType {
    Registry = "Registry",
    OTConnector = "OTConnector",
    Utility = "Utility",
    Persistence = "Persistence",
    Aggregation = "Aggregation",
    OOCConnector = "OOCConnector",
    ITConnector = "ITConnector"
}
