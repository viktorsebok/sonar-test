import { ILicenseObject } from '@oi4/oi4-oec-service-model';
export declare function licenseFileToLicenseObject(filePath: string, encoding: string): ILicenseObject[];
